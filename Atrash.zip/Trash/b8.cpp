#include <iostream>
#include <omp.h>
using namespace std;

class prim
{
	int v,a[10][10],vis[10];
 
public:
 
	prim() 			//Constructor
 	{ 
 		v=0;
  		for(int i=0;i<10;i++)
  		{ 
   			vis[i]=-1;
   			for(int j=0;j<10;j++)
  				a[i][j]=99;
   			
  		}
 	}
 
 
 	void create()					//Create the graph
 	{
  		cout<<"Enter number of nodes."<<endl;
  		cin>>v;
  		for(int i=0;i<v;i++)
    		{
    			for(int j=i+1;j<v;j++)
     			{ 
      				cout<<"Enter distance from node "<<i<<" to "<<j<<endl;;
      				cin>>a[i][j];
      				if(a[i][j]==0) 
      					a[i][j]=99;
      				a[j][i]=a[i][j];

     			}
    		}
 	}


 	void setvis(int d)				//Visit a node
 	{
  		vis[d]=d;
  		cout<<"Node "<<d<<" ";
 	}
 
 
 	int chkvis(int d)				//Check if node is visited
  	{
   		if(vis[d]==d)
   			return 1;
   		else 
   			return 0;
  	}


 	void prims()					//Prim's Algorithm
 	{
  		int min=99,total=0,k,l;
  
  		for(int i=0;i<v;i++)		//Finds the smallest edge
  		{
   			for(int j=0;j<v;j++)
   			{
    				if(a[i][j]<min)
    				{
     					min=a[i][j];
     					k=i;
     					l=j;
    				}
   			}
  		}
  
  		total=min;
  		setvis(k);			//Visits the nodes
  		cout<<"--> ";
  		setvis(l);
  
  		cout<<" Cost: "<<a[k][l]<<endl;
  
  		for(int m=0;m<v-2;m++)		//Finds the next smallest edge
  		{
   			min=99;
   			int minlist[10],tid;
   			for(int p=0;p<10;p++)
    				minlist[p]=0;
    
   			omp_set_num_threads(v);				//Creates one thread per node
   			#pragma omp parallel private(minlist, tid)
   
   			{
    				tid=omp_get_thread_num();
    				if(chkvis(tid)==1)			//Each thread checks for the smallest edge from its node
    				{
     					for(int j=0;j<v;j++)
     					{
      						if(chkvis(j)==0)
      						{
       							if(a[tid][j]<min)
       							{
        							min=a[tid][j];
        							k=tid;
        							l=j;
       							}
      						}
     					}
     					
    					minlist[tid]=min;
    				}

   			}

  			for(int q=0;q<v;q++)
  			{
   				if(minlist[q]<min)
    					min=minlist[q];
  			}
  
  			setvis(k);
  			cout<<"--> ";
  			setvis(l);
  			cout<<" Cost: "<<a[k][l]<<endl;
  			total=total+a[k][l];
  		}
  		
  		cout<<"Total cost of MST: "<<total<<endl;
 	}


	void display()
 	{
 		for(int i=0;i<v;i++)
 		{
  			for(int j=0;j<v;j++)
  			   cout<<a[i][j]<<" ";
  
 			cout<<endl;
 		}
		cout<<endl;
 	}	
};

int main() 
{
 	prim p;
 	p.create();
 	cout<<"\nGraph Matrix: "<<endl;
 	p.display();
 	p.prims();

 	return 0;
}
