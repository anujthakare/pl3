import java.io.*;
import java.net.*;

public class clientdemo
{
	public static void main(String ar[])
{
	try
{
	String msg;
	Socket sct=new Socket("127.0.0.1",2003);
	BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
	BufferedReader br1=new BufferedReader(new InputStreamReader(sct.getInputStream()));
	PrintWriter out=new PrintWriter(new BufferedWriter(new OutputStreamWriter(sct.getOutputStream())),true);

	System.out.println("Enter Message");
	while((msg=br.readLine())!=null)
{
	out.println(msg);
	String a = br1.readLine();
	if(a.equals("bye"))
	{
		break;
	}
	System.out.println("Echo Message :"+ a);

}
}
catch(Exception e)
{
	
}
}

} 
