Roll no. 3253
Batch: M2

#BBBcode:

import os
import time
print "1.BBB to machine \n 2.ftp to BBB \n 3.machine to BBB \n 4.bbb to ftp"
a=int(input("enter your choice"))
if(a==1):
        os.system("ls")
        b=raw_input("choose your file ")
        time.sleep(2)
        comm="scp /root/"+b+" pict@192.168.5.214:/home/pict/"
        print comm
        os.system(comm)
        print("file transferred")

elif(a==3):
        os.system("ssh root@192.168.5.214 python /home/pict/b2a.py")
       

elif(a==2):
        os.system("sftp print16-17@192.168.5.71")
     

elif(a==4):
        os.system("sftp print16-17@192.168.5.71")
       
#remotecode:

import os
import time
os.system("ls /home/pict")
c=raw_input("choose your file")
time.sleep(2)
comd="scp /home/pict/"+c+" root@192.168.5.215:/root/"
os.system(comd)
print("file transferred")
os.system("exit")
