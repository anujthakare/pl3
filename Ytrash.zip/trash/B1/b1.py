
import os

#300mhz
print "Current frequency: 300MHz"
os.system("cpufreq-set -f 300Mhz")
os.system("python fact.py")
os.system("python bubble.py")
os.system("python gcd1.py")
print "\n"

#500mhz
print "Current frequency: 500MHz"
os.system("cpufreq-set -f 500Mhz")
os.system("python fact.py")
os.system("python bubble.py")
os.system("python gcd1.py")
print "\n"

#1000mhz
print "Current frequency: 1000MHz"
os.system("cpufreq-set -f 1000Mhz")
os.system("python fact.py")
os.system("python bubble.py")
os.system("python gcd1.py")
print "\n"

os.system("cpufreq-set -f 300Mhz")

#fact.py
import sys,time
def Factorial():
    n = 100
    fact=1
    for i in range(1,n+1):
       fact=fact*i

start_time=time.time()
Factorial()
print "Time taken in fact.py: %s seconds" % (time.time()-start_time)

#bubble.py
import sys,time

def bubbleSort(alist):
    for passnum in range(len(alist)-1,0,-1):
        for i in range(passnum):
            if alist[i]>alist[i+1]:
                temp = alist[i]
                alist[i] = alist[i+1]
                alist[i+1] = temp

alist = [54,26,93,17,77,31,44,55,20]
start_time=time.time()
bubbleSort(alist)
print "Time taken in bubble.py: %s seconds" % (time.time()-start_time)

#gcd1.py
import sys,time

def computerHCF(x, y):
   if x > y:
       smaller = y
   else:
       smaller = x

   for i in range(1,smaller + 1):
       if((x % i == 0) and (y % i == 0)):
           hcf = i
       return hcf

num1 = 54
num2 = 24
start_time=time.time()
computerHCF(num1, num2)
print "Time taken by gcd1.py: %s seconds" % (time.time()- start_time)
