import Adafruit_BBIO.GPIO as GPIO
import time

GPIO.setup("P9_11",GPIO.OUT);		#RED 1
GPIO.setup("P9_13",GPIO.OUT);		#YELLOW 1
GPIO.setup("P9_15",GPIO.OUT);		#GREEN 1
GPIO.setup("P8_08",GPIO.OUT);		#RED 2
GPIO.setup("P8_10",GPIO.OUT);		#YELLOW 2
GPIO.setup("P8_14",GPIO.OUT);		#GREEN 2

GPIO.output("P9_11",GPIO.LOW);
GPIO.output("P9_13",GPIO.LOW);
GPIO.output("P9_15",GPIO.LOW);
GPIO.output("P8_08",GPIO.LOW);
GPIO.output("P8_10",GPIO.LOW);
GPIO.output("P8_14",GPIO.LOW);

while True:
	GPIO.output("P9_13",GPIO.LOW);		#YELLOW 1 is LOW
	print("#YELLOW 1 is LOW");
	GPIO.output("P9_11",GPIO.HIGH);		#RED 1 is HIGH
	print("#RED 1 is HIGH");
	GPIO.output("P8_14",GPIO.HIGH);		#GREEN 2 is HIGH
	PRINT("#GREEN 2 is HIGH");
	time.sleep(2);
	GPIO.output("P8_14",GPIO.LOW);		#GREEN 2 is LOW while RED 1 is still HIGH
	print("#GREEN 2 is LOW while RED 1 is still HIGH");
	GPIO.output("P8_10",GPIO.HIGH);		#YELLOW 2 is HIGH
	print("#YELLOW 2 is HIGH");
	time.sleep(1);
	GPIO.output("P9_11",GPIO.LOW);		#RED 1 is LOW
	print("#RED 1 is LOW");
	GPIO.output("P8_10",GPIO.LOW);		#YELLOW 2 is LOW
	print("#YELLOW 2 is LOW");
	GPIO.output("P9_15",GPIO.HIGH);		#GREEN 1 is HIGH
	print("#GREEN 1 is HIGH");
	GPIO.output("P8_08",GPIO.HIGH);		#RED 2 is HIGH
	print("#RED 2 is HIGH");
	time.sleep(2);
	GPIO.output("P9_15",GPIO.LOW);		#GREEN 1 is LOW
	print(":#GREEN 1 is LOW");
	GPIO.output("P9_13",GPIO.HIGH);		#YELLOW 1 is HIGH
	print("#YELLOW 1 is HIGH");
	time.sleep(1);
	
