//Name:Shweta Shinde
//Roll No:3359

import Adafruit_BBIO.GPIO as GPIO
import time
GPIO.setup("P8_9", GPIO.OUT)
GPIO.setup("P8_10", GPIO.OUT)
GPIO.setup("P8_11", GPIO.OUT)
GPIO.setup("P8_12", GPIO.OUT)
GPIO.setup("P8_13", GPIO.OUT)
GPIO.setup("P8_14", GPIO.OUT)
while True:
 GPIO.output("P8_9", GPIO.HIGH)
 GPIO.output("P8_10", GPIO.LOW)
 GPIO.output("P8_11", GPIO.LOW)
 GPIO.output("P8_12", GPIO.LOW)
 GPIO.output("P8_13", GPIO.LOW)
 GPIO.output("P8_14", GPIO.HIGH)
 print("2nd Green Light")
 time.sleep(5)

 GPIO.output("P8_9", GPIO.HIGH)
 GPIO.output("P8_10", GPIO.LOW)
 GPIO.output("P8_11", GPIO.LOW)
 GPIO.output("P8_12", GPIO.LOW)
 GPIO.output("P8_13", GPIO.HIGH)
 GPIO.output("P8_14", GPIO.LOW)
 print("R1 Red is high and Y2 Yellow is high")

 time.sleep(3)

 GPIO.output("P8_9", GPIO.LOW)
 GPIO.output("P8_10", GPIO.LOW)
 GPIO.output("P8_11", GPIO.HIGH)
 GPIO.output("P8_12", GPIO.HIGH)
 GPIO.output("P8_13", GPIO.LOW)
 GPIO.output("P8_14", GPIO.LOW)
 print("1st Green and R2 Red is High")
 
 time.sleep(5)
              
 GPIO.output("P8_9", GPIO.LOW)
 GPIO.output("P8_10", GPIO.HIGH)
 GPIO.output("P8_11", GPIO.LOW)
 GPIO.output("P8_12", GPIO.HIGH)
 GPIO.output("P8_13", GPIO.LOW)
 GPIO.output("P8_14", GPIO.LOW)
 print("1st Green is High and 2 red is High")
 time.sleep(3)                   
                                 
