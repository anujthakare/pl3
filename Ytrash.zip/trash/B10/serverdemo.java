import java.net.*;
import java.io.*;
import java.lang.Thread.*;
public class serverdemo
{
	public static void main(String ar[])
{
	try
{
	ServerSocket sr=new ServerSocket(2003);
	while(true)
{
	Socket sct=sr.accept();
	EchoH eh=new EchoH(sct);
	eh.start();

}	
}
	catch(Exception e)
{
	System.out.println(e);
}
} 
}
	class EchoH extends Thread
{
	Socket sct;
	EchoH(Socket sct)
{
	this.sct=sct;

}
	public void run()
{
	try
{
	String thr=Thread.currentThread().getName();

	BufferedReader br=new BufferedReader(new InputStreamReader(sct.getInputStream()));
	PrintWriter pr=new PrintWriter(sct.getOutputStream(),true);
	String msg;
	while(true)
{

	msg=br.readLine();
	System.out.println("Message From:"+sct);
	System.out.println("msg: "+ msg + " from " +thr+ " thread ");	
	pr.println(msg);
	if(msg.equals("bye"))
{
	pr.println(msg);
	//Thread.currentThread().stop();
	sct.close();
	

}

}
}
catch(Exception e)
{
	
}
finally
{
	try
{	
	sct.close();
}
	

catch(Exception e)
{
	
}

}

}
}