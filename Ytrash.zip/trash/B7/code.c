#include <stdio.h>
#include <sched.h>
#include <omp.h>

int num;

void main()
{
	int index;
	int i,s,arr[1000];
	for(i=0;i<1000;i++)
		arr[i]=2*i;
	printf("\nEnter number to be searched: ");
	scanf("%d",&num);
	index=narray(arr,0,999);
	if(index==-1) 
		printf("\nElement not found...\n");
	else 
		printf("\nElement found at position %d\n",index+1);
}

int narray(int arr[],int lb,int ub)
{
	if(lb<=ub)
	{
		int i,res[4],position[4],size,p_size,id,pos,index=-1,new_ub,new_lb;
		printf("\n\nSearching between %d and %d...",arr[lb],arr[ub]);

		//if element is out of bounds, exit
		if(num<arr[lb]||num>arr[ub]) 
			return -1;

		//size of array
		size=ub-lb+1;
		printf("\nsize of array=%d",size);

		//partition size
		p_size=size/5;

		//if array cant be divided in 5 parts
		if(p_size==0)
		{
			#pragma omp parallel private(id)
			{
				id=omp_get_thread_num();
				if((lb+id)<=ub&&arr[id+lb]==num)
					index=id+lb;
			}
			return index;
		}
		//array size >= 5
		else
		{
			#pragma omp parallel private(id,pos)
			{
				id=omp_get_thread_num();
				pos=lb+(id+1)*p_size;

				//current position of each thread is stored in position[]
				position[id]=pos;
				printf("\nChecking with thread id %d on cpu %d",omp_get_thread_num(),sched_getcpu());
				if(arr[pos]==num)
					index=pos;
				//if res[id] is 1, element is at right of current thread, if 0 element is at left
				else if(arr[pos]<num) 
					res[id]=1;
				else 
					res[id]=0;
			}
			if(index!=-1) 
				return index;

			//determining which part contains element, set new_lb and new_ub accordingly
			if(res[0]==0)
			{
				new_lb=lb;
				new_ub=position[0]-1;
			}
			else if(res[3]==1)
			{	
				new_lb=position[3]+1;
				new_ub=ub;
			}
			else 
				for(i=0;i<3;i++)
					if(res[i]!=res[i+1])
					{
						new_lb=position[i]+1;
						new_ub=position[i+1]-1;
						break;
					}
		}

		//calling this again with part of array determined above
		narray(arr,new_lb,new_ub);
	}
	else 
		return -1;
}
